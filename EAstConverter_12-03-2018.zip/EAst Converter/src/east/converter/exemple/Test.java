/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package east.converter.exemple;

/**
 *
 * @author Serigne
 */
import static east.converter.core.XmlOperations.getDate;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.poi.hslf.model.HeadersFooters;
import org.apache.poi.hslf.usermodel.HSLFPictureData;
import org.apache.poi.hslf.usermodel.HSLFPictureShape;
import org.apache.poi.hslf.usermodel.HSLFSlide;
import org.apache.poi.hslf.usermodel.HSLFSlideShow;
import org.apache.poi.hslf.usermodel.HSLFTextBox;
import org.apache.poi.hslf.usermodel.HSLFTextParagraph;
import org.apache.poi.sl.usermodel.PictureData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Test {

    public static void main(String[] args) throws Exception {
        Test test = new Test();
        test.runTest();
    }

    public void runTest() throws Exception {

        File xmlEast = new File("src/eastxml.xml");
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlEast);

        //optional, but recommended
        doc.getDocumentElement().normalize();
        String rootElement = doc.getDocumentElement().getNodeName();
        if (!rootElement.equals("EAST")) {
            //JOptionPane.showMessageDialog(this, "Votre fichier XML EAST est invalide", null, JOptionPane.INFORMATION_MESSAGE);
        } else {

            //create a new empty slide show
            HSLFSlideShow pptx = new HSLFSlideShow();

            // Information Footer du slide
            HeadersFooters hdd = pptx.getSlideHeadersFooters();
            hdd.setSlideNumberVisible(true);

            // Recuperation des pieds de page
            // gauche et droite
            NodeList piedsPageGauche = doc.getElementsByTagName("PIEDPAGE_GAUCHE");
            for (int i = 0; i < piedsPageGauche.getLength(); i++) {
                Node nNode = piedsPageGauche.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    if (eElement.getTextContent().length() > 0) {
                        hdd.setFootersText(eElement.getTextContent());
                    }
                }
            }

            NodeList piedsPageDroite = doc.getElementsByTagName("PIEDPAGE_DROIT");
            for (int i = 0; i < piedsPageDroite.getLength(); i++) {
                Node nNode = piedsPageDroite.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    if (eElement.getTextContent().length() > 0) {
                        hdd.setFootersText(hdd.getFooterText() + " - " + eElement.getTextContent());
                    }
                }
            }

            //Recuperation de la page tire PAGE_TITRE == FIRST SLIDE
            NodeList PageTitre = doc.getElementsByTagName("PAGE_TITRE");
            for (int i = 0; i < PageTitre.getLength(); i++) {
                Node nNode = PageTitre.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    String titre = (eElement.getElementsByTagName("TITRE").item(0) != null) ? eElement.getElementsByTagName("TITRE").item(0).getTextContent() : "Pas de titre";
                    String sous_titre = (eElement.getElementsByTagName("SOUS_TITRE").item(0) != null) ? eElement.getElementsByTagName("SOUS_TITRE").item(0).getTextContent() : "Pas de sujet";
                    String auteur = (eElement.getElementsByTagName("AUTEUR").item(0) != null) ? eElement.getElementsByTagName("AUTEUR").item(0).getTextContent() : "Pas d'auteur";
                    String email = (eElement.getElementsByTagName("EMAIL").item(0) != null) ? eElement.getElementsByTagName("EMAIL").item(0).getTextContent() : "Pas d'email";

                    // Renseignement des proprietes du fichier
                    // Auteur - Sujet - Email...
                }
            }

            // PARTIE Donc des SECTION == SLIDE 
            NodeList SectionsList = doc.getElementsByTagName("SECTION");
            for (int index = 0; index < SectionsList.getLength(); index++) {
                Node nNodeSection = SectionsList.item(index);
                HSLFSlide slide = pptx.createSlide();
                int Y = 0;
                int X = 0;

                if (nNodeSection.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNodeSection;

                    // Recuperation du titre du SLIDE
                    /*if (eElement.getElementsByTagName("TITRE").item(0) != null) {
                     String titreSlide = eElement.getElementsByTagName("TITRE").item(0).getTextContent();
                     TextBox title = slide.addTitle();
                     title.setText(titreSlide);
                     }*/
                    // Recuperation des paragraphes qui seront nos SHAPES
                    NodeList SectionsParagraphList = eElement.getElementsByTagName("PARAGRAPHE");
                    for (int j = 0; j < SectionsParagraphList.getLength(); j++) {
                        if (SectionsParagraphList.item(j) != null) {
                            Y += 70;
                            HSLFTextBox paragraphe = new HSLFTextBox();
                            paragraphe.setText(SectionsParagraphList.item(j).getTextContent());
                            paragraphe.setAnchor(new java.awt.Rectangle(300, Y, 300, 50));
                            slide.addShape(paragraphe);

                        }
                    }

                    // Recuperation des Images
                    NodeList SectionsImagesList = eElement.getElementsByTagName("ENVIMAGE");
                    for (int k = 0; k < SectionsImagesList.getLength(); k++) {
                        if (SectionsImagesList.item(k) != null) {
                            Element eImage = (Element) SectionsImagesList.item(k);
                            int ImgWidth = Integer.parseInt(eImage.getElementsByTagName("IMAGE").item(0).getAttributes().item(3).getTextContent());
                            int ImgHeight = Integer.parseInt(eImage.getElementsByTagName("IMAGE").item(0).getAttributes().item(2).getTextContent());
                            String ImgSrc = eImage.getElementsByTagName("IMAGE").item(0).getAttributes().item(1).getTextContent();

                            //Renommage du fichier image pour ne prendre que le path total;
                            ImgSrc = ImgSrc.replaceFirst("file:///", "");

                            // Ajout des images dans notre slide
                            HSLFPictureData pd = pptx.addPicture(new File(ImgSrc), PictureData.PictureType.PNG);

                            HSLFPictureShape pictNew = new HSLFPictureShape(pd);

                            // set image position in the slide
                            Y += 50;
                            pictNew.setAnchor(new java.awt.Rectangle(100, Y, 300, 200));
                            slide.addShape(pictNew);
                        }
                    }

                    // Recuperations des EL = listes � puces
                    NodeList SectionsListeList = eElement.getElementsByTagName("LISTE");
                    for (int l = 0; l < SectionsListeList.getLength(); l++) {
                        if (SectionsListeList.item(l) != null) {

                            // Ajout d'une liste a notre slide
                            HSLFTextBox shape = new HSLFTextBox();
                            HSLFTextParagraph tp = shape.getTextParagraphs().get(0);
                            tp.setBullet(true);
                            tp.setBulletChar('\u2022'); //Caractere puce point noir
                            tp.setIndent(0.);
                            tp.setLeftMargin(50.);
                            shape.setText("");

                            Element eListe = (Element) SectionsListeList.item(l);
                            NodeList SectionsElList = eListe.getElementsByTagName("EL");
                            for (int m = 0; m < SectionsElList.getLength(); m++) {
                                if (SectionsElList.item(m) != null) {
                                    shape.setText(shape.getText() + SectionsElList.item(m).getTextContent() + "\r");
                                }
                            }

                            Y += 50;
                            shape.setAnchor(new java.awt.Rectangle(50, Y, 500, 300));
                            slide.addShape(shape);
                        }
                    }

                }
            }

            try {
                FileOutputStream out = new FileOutputStream("FromEAstToPowerpoint-" + getDate() + ".ppt");
                pptx.write(out);
                out.close();
            } catch (FileNotFoundException e) {
            } catch (IOException e) {
            }
        }

    }
}
