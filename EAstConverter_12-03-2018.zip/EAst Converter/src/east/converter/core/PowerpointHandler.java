/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package east.converter.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.bind.JAXBException;
import org.apache.poi.POIXMLProperties;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.xmlbeans.XmlException;

/**
 *
 * @author Serigne
 */
public class PowerpointHandler {

    /**
     * Permet de PARSET un fichier PPTX vers un fichier XML valide
     *
     * @param pptxFile
     * @throws IOException
     * @throws OpenXML4JException
     * @throws JAXBException
     */
    public void PPTX(File pptxFile) throws IOException, OpenXML4JException, JAXBException, XmlException {
        PrintStream out = System.out;
        if (pptxFile.length() == 0) {
            out.println("Un fichier Powerpoint est requis pour continuer");
            return;
        }

        FileInputStream is = new FileInputStream(pptxFile);
        try (XMLSlideShow ppt = new XMLSlideShow(is)) {
            is.close();

            // Metadata - Informations du fichier
            Map<String, String> meta = new HashMap<>();
            OPCPackage pkg = OPCPackage.open(pptxFile);
            POIXMLProperties props = new POIXMLProperties(pkg);

            // Stockage des infos du fichier dans une MAP (Cl�, Valeur)
            meta.put("nom", pptxFile.getName());
            meta.put("nom_sans_extension", pptxFile.getName().substring(0, pptxFile.getName().lastIndexOf(".")));
            meta.put("titre", (props.getCoreProperties().getTitle().length() > 0) ? props.getCoreProperties().getTitle() : "Pas de titre");
            meta.put("auteur", (props.getCoreProperties().getCreator().length() > 0) ? props.getCoreProperties().getCreator() : "Pas d'auteur");
            meta.put("sous_titre", (props.getCoreProperties().getSubject().length() > 0) ? props.getCoreProperties().getSubject() : "Pas de sous titre");
            meta.put("date_creation", (props.getCoreProperties().getCreated().toString().length() > 0) ? props.getCoreProperties().getCreated().toString() : "Pas de date");

            XmlOperations ops = new XmlOperations();
            ops.generateEastXml(meta, ppt);
        }
    }
}
