/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package east.converter.core;

import java.io.File;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;

import generated.*;
import java.awt.Component;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.poi.hslf.model.HeadersFooters;
import org.apache.poi.hslf.usermodel.HSLFPictureData;
import org.apache.poi.hslf.usermodel.HSLFPictureShape;
import org.apache.poi.hslf.usermodel.HSLFSlide;
import org.apache.poi.hslf.usermodel.HSLFSlideShow;
import org.apache.poi.hslf.usermodel.HSLFTextBox;
import org.apache.poi.hslf.usermodel.HSLFTextParagraph;
import org.apache.poi.sl.usermodel.PictureData;
import org.apache.poi.sl.usermodel.PictureData.PictureType;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFPictureData;
import org.apache.poi.xslf.usermodel.XSLFPictureShape;
import org.apache.poi.xslf.usermodel.XSLFShape;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFTextParagraph;
import org.apache.poi.xslf.usermodel.XSLFTextShape;
import org.odftoolkit.odfdom.pkg.OdfFileDom;
import org.odftoolkit.simple.PresentationDocument;
import org.odftoolkit.simple.draw.Image;
import org.odftoolkit.simple.draw.Textbox;
import org.odftoolkit.simple.meta.Meta;
import org.odftoolkit.simple.presentation.Slide;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Serigne
 */
public class XmlOperations {

    // ODP file 
    PresentationDocument presentationmodel;
    static final int LargParDefaut = 15;  // Image Width en %
    static final int HautParDefaut = 15; // Image Height en %

    /**
     * Generer le fichier XML EAST VALID � partir de notre fichier POWERPOINT
     *
     * @param meta LES METADONNEES LIEES AU FICHIER POWERPOINT
     * @param ppt
     * @throws PropertyException
     * @throws JAXBException
     * @throws java.io.FileNotFoundException
     */
    public void generateEastXml(Map meta, XMLSlideShow ppt) throws PropertyException, JAXBException, FileNotFoundException, IOException {

        // Instanciation d'un nouveau document EAST
        // FEUILLE EAST correspond � UNE DOCUMENT PPTX
        EAST Feuille = new EAST();

        Feuille.setPIEDPAGEGAUCHE(meta.get("date_creation").toString());
        Feuille.setPIEDPAGEDROIT(meta.get("nom_sans_extension").toString());

        // Ajout d'un noeud page_titre dans la feuille east
        PAGETITRE page_titre = new PAGETITRE();
        page_titre.setTITRE(meta.get("titre").toString());
        page_titre.setSOUSTITRE(meta.get("sous_titre").toString());
        page_titre.getAUTEUR().add(meta.get("auteur").toString());
        //page_titre.getEMAIL().add("massebodian@mail.com");
        Feuille.setPAGETITRE(page_titre);

        // Defition de la partie
        PARTIE partie = new PARTIE();
        partie.setTITRE(meta.get("titre").toString());

        // Ceci zone represente un SLIDE EN POWERPOINT
        // Parcours des slides present dans notre document pptx
        for (XSLFSlide slide : ppt.getSlides()) {

            // SECTIONS(EAST) = SLIDE (POWERPOINT)
            SECTION currentSection = new SECTION();

            // Parcours des zones de textes dans les slides
            int ShapeIterator = 0;
            for (XSLFShape shape : slide) {

                // UNE SHAPE EN POWERPOINT CORRESPON � UNE ZONE DANS LE SLIDE
                // ELLE PEUT CONTENIR DU TEXTE OU UNE IMAGE/VIDEO/GRAPHIQUE
                PARAGRAPHE paragraphe;
                LISTE liste = new LISTE();
                EL element = null;
                boolean listExist = false;

                // Le shape est un TEXTE
                if (shape instanceof XSLFTextShape) {
                    XSLFTextShape txShape = (XSLFTextShape) shape;

                    // On test si le texte correspond au titre du slide
                    // Si oui on le met comme le titre de la section
                    if (txShape.getTextType() != null && txShape.getTextType().toString().equals("TITLE")) {
                        currentSection.setTITRE(txShape.getText());
                        System.out.println("Titre : " + txShape.getTextType().toString());
                    }

                    // Recuperation du texte puis on le met dans une paragraphe EAST
                    // On ne recupere pas le texte de type PIED DE PAGE ou NUMERO DE PAGE
                    if (txShape.getTextType() != null
                            && !txShape.getTextType().toString().equals("FOOTER")
                            && !txShape.getTextType().toString().equals("SLIDE_NUMBER")
                            && txShape.getText().length() > 0) {

                        for (int i = 0; i < txShape.getTextParagraphs().size(); i++) {
                            XSLFTextParagraph currentParag = txShape.getTextParagraphs().get(i);

                            // Test Si la paragraphe est une PUCE (Liste) = EL (EAst)
                            if (currentParag.isBullet()) {
                                listExist = true;
                                element = new EL();
                                element.getContent().add(currentParag.getText());
                                liste.getEL().add(element);
                            } else {
                                if (currentParag.getText().length() > 0) {
                                    paragraphe = new PARAGRAPHE();
                                    paragraphe.getContent().add(currentParag.getText());
                                    currentSection.getPARAGRAPHEOrLISTEOrLISTEDEF().add(paragraphe);
                                }
                            }
                        }

                        // S'il existait une liste dans le SHAPE
                        // Ajouter La liste dand la section courrante
                        if (listExist) {
                            currentSection.getPARAGRAPHEOrLISTEOrLISTEDEF().add(liste);
                        }
                    }
                } else if (shape instanceof XSLFPictureShape) { // SHAPE est une image
                    XSLFPictureShape pShape = (XSLFPictureShape) shape;
                    XSLFPictureData pData = pShape.getPictureData();

                    //  Recuperation & Creation des images
                    byte[] metadonnees = pData.getData();
                    PictureType type = pData.getType();
                    String imageName = "image_";
                    if (type.compareTo(PictureType.JPEG) == 0) {
                        imageName = imageName + ShapeIterator + ".jpg";
                        FileOutputStream out3 = new FileOutputStream(imageName);
                        out3.write(metadonnees);
                        out3.close();
                    } else if (type.compareTo(PictureType.PNG) == 0) {
                        imageName = imageName + ShapeIterator + ".png";
                        FileOutputStream out4 = new FileOutputStream(imageName);
                        out4.write(metadonnees);
                        out4.close();
                    }

                    // On declare un environnement IMAGE EAST
                    // C'est juste une ZONE QUI PREND une IMAGE dans la SECTION EAST
                    ENVIMAGE img_wrapper = new ENVIMAGE();
                    IMAGEOBJECT img = new IMAGEOBJECT();

                    img.setAlt("Test image");
                    img.setFichier("file:///" + new File(imageName).getAbsolutePath());
                    img.setHauteur(HautParDefaut);
                    img.setLargeur(LargParDefaut);
                    img_wrapper.setIMAGEOBJECT(img);
                    img_wrapper.setImage(img.getFichier());
                    currentSection.getPARAGRAPHEOrLISTEOrLISTEDEF().add(img_wrapper);
                }

                ShapeIterator++;
            }

            // Ajout de la section = SLIDE qu'on vient de parcourir dans la PARTIE
            partie.getSECTION().add(currentSection);
        }

        // AU FINAL ON AJOUTE LA PARTIE DANS LA FEUILLE EAST
        Feuille.getPARTIE().add(partie);

        // Processing PPTX_EAST_XML_FILE
        File fichierXml = new File("PowerpointEAST_genere-le-" + getDate() + ".xml");
        JAXBContext context = JAXBContext.newInstance("generated");
        Marshaller jaxbMarshaller = context.createMarshaller();
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        // La on ecrit le xml dans le fichier XML
        // Ce fichier se trouve dans le r�p�etoire NETBEANS du projet
        jaxbMarshaller.marshal(Feuille, fichierXml);

        // Afficher le code xml g�n�r� dans la console pour voir le resultat
        //jaxbMarshaller.marshal(Feuille, System.out);
    }

    // Retourne la date courante de generation du fichier EAST
    public static String getDate() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDateTime now = LocalDateTime.now();
        return dtf.format(now);
    }

    /**
     * Permet de g�n�rer un fichier
     *
     * @param fileName
     * @param impressFile
     */
    public void generateImpressXml(String fileName, File impressFile) throws Exception {
        PresentationDocument presentation = (PresentationDocument) PresentationDocument.loadDocument(impressFile);
        Textbox footer = null;
        OdfFileDom metadom = presentation.getMetaDom();
        Meta metadata = new Meta(metadom);

        // Instanciation d'un nouveau document EAST
        // FEUILLE EAST correspond � UNE DOCUMENT PPTX
        EAST Feuille = new EAST();
        Feuille.setPIEDPAGEDROIT(metadata.getCreationDate().getTime().toString());

        // Ajout d'un noeud page_titre dans la feuille east
        PAGETITRE page_titre = new PAGETITRE();
        page_titre.setTITRE(metadata.getTitle());
        page_titre.getAUTEUR().add(metadata.getCreator());
        Feuille.setPAGETITRE(page_titre);

        // Defition de la partie
        PARTIE partie = new PARTIE();
        partie.setTITRE(fileName);

        for (Iterator<Slide> slideList = presentation.getSlides(); slideList.hasNext();) {
            Slide slideObject = slideList.next();
            // SECTIONS(EAST) = SLIDE (POWERPOINT)
            SECTION currentSection = new SECTION();

            // On recupere le FOOTER et on defini un OBJET FOOTER EAST
            if (footer == null) {
                try {
                    footer = slideObject.getTextboxByUsage(PresentationDocument.PresentationClass.FOOTER).get(0);
                    if (footer != null) {
                        Feuille.setPIEDPAGEGAUCHE(footer.getTextContent());
                    }
                } catch (IndexOutOfBoundsException e) {
                }
            }

            //Textbox titleBox = slideObject.getTextboxByUsage(PresentationDocument.PresentationClass.TITLE).get(0);
            //System.out.println("\n\n**Diapositive ** " + titleBox.getTextContent());
            for (Iterator<Textbox> ShapesList = slideObject.getTextboxIterator(); ShapesList.hasNext();) {

                PARAGRAPHE paragraphe = new PARAGRAPHE();

                if (slideObject.getTextboxByUsage(PresentationDocument.PresentationClass.GRAPHIC) instanceof Image) {
                    // PROCESSING des ImageElement dans le SLIDE impress
                } else {
                    // Recuperation des Textes dans le slide
                    Textbox shape = ShapesList.next();
                    paragraphe.getContent().add(shape.getTextContent());
                }

                currentSection.getPARAGRAPHEOrLISTEOrLISTEDEF().add(paragraphe);
            }

            partie.getSECTION().add(currentSection);
        }

        // AU FINAL ON AJOUTE LA PARTIE DANS LA FEUILLE EAST
        Feuille.getPARTIE().add(partie);

        // Processing PPTX_EAST_XML_FILE
        File fichierXml = new File("ImpressEAST_genere-le-" + getDate() + ".xml");
        JAXBContext context = JAXBContext.newInstance("generated");
        Marshaller jaxbMarshaller = context.createMarshaller();
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        // La on ecrit le xml dans le fichier XML
        // Ce fichier se trouve dans le r�p�etoire NETBEANS du projet
        jaxbMarshaller.marshal(Feuille, fichierXml);
    }

    /**
     * Cette fonction permet de convertir un fichier EAST xml ver Powerpoint
     *
     * @param xmlEast
     * @throws java.io.IOException
     * @throws org.xml.sax.SAXException
     * @throws javax.xml.parsers.ParserConfigurationException
     */
    public void eastXmlToPowerpoint(File xmlEast, Component parent) throws IOException, SAXException, ParserConfigurationException {
        //File xmlEast = new File("src/eastxml.xml");
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlEast);

        //optional, but recommended
        doc.getDocumentElement().normalize();
        String rootElement = doc.getDocumentElement().getNodeName();
        if (!rootElement.equals("EAST")) {
            JOptionPane.showMessageDialog(parent, "Votre fichier XML EAST est invalide", null, JOptionPane.INFORMATION_MESSAGE);
        } else {

            //create a new empty slide show
            HSLFSlideShow pptx = new HSLFSlideShow();

            // Information Footer du slide
            HeadersFooters hdd = pptx.getSlideHeadersFooters();
            hdd.setSlideNumberVisible(true);

            // Recuperation des pieds de page
            // gauche et droite
            NodeList piedsPageGauche = doc.getElementsByTagName("PIEDPAGE_GAUCHE");
            for (int i = 0; i < piedsPageGauche.getLength(); i++) {
                Node nNode = piedsPageGauche.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    if (eElement.getTextContent().length() > 0) {
                        hdd.setFootersText(eElement.getTextContent());
                    }
                }
            }

            NodeList piedsPageDroite = doc.getElementsByTagName("PIEDPAGE_DROIT");
            for (int i = 0; i < piedsPageDroite.getLength(); i++) {
                Node nNode = piedsPageDroite.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    if (eElement.getTextContent().length() > 0) {
                        hdd.setFootersText(hdd.getFooterText() + " - " + eElement.getTextContent());
                    }
                }
            }

            //Recuperation de la page tire PAGE_TITRE == FIRST SLIDE
            NodeList PageTitre = doc.getElementsByTagName("PAGE_TITRE");
            for (int i = 0; i < PageTitre.getLength(); i++) {
                Node nNode = PageTitre.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    String titre = (eElement.getElementsByTagName("TITRE").item(0) != null) ? eElement.getElementsByTagName("TITRE").item(0).getTextContent() : "Pas de titre";
                    String sous_titre = (eElement.getElementsByTagName("SOUS_TITRE").item(0) != null) ? eElement.getElementsByTagName("SOUS_TITRE").item(0).getTextContent() : "Pas de sujet";
                    String auteur = (eElement.getElementsByTagName("AUTEUR").item(0) != null) ? eElement.getElementsByTagName("AUTEUR").item(0).getTextContent() : "Pas d'auteur";
                    String email = (eElement.getElementsByTagName("EMAIL").item(0) != null) ? eElement.getElementsByTagName("EMAIL").item(0).getTextContent() : "Pas d'email";

                    // Renseignement des proprietes du fichier
                    // Auteur - Sujet - Email...
                }
            }

            // PARTIE Donc des SECTION == SLIDE 
            NodeList SectionsList = doc.getElementsByTagName("SECTION");
            for (int index = 0; index < SectionsList.getLength(); index++) {
                Node nNodeSection = SectionsList.item(index);
                HSLFSlide slide = pptx.createSlide();
                int Y = 0;
                int X = 0;

                if (nNodeSection.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNodeSection;

                    // Recuperation du titre du SLIDE
                    /*if (eElement.getElementsByTagName("TITRE").item(0) != null) {
                     String titreSlide = eElement.getElementsByTagName("TITRE").item(0).getTextContent();
                     TextBox title = slide.addTitle();
                     title.setText(titreSlide);
                     }*/
                    // Recuperation des paragraphes qui seront nos SHAPES
                    NodeList SectionsParagraphList = eElement.getElementsByTagName("PARAGRAPHE");
                    for (int j = 0; j < SectionsParagraphList.getLength(); j++) {
                        if (SectionsParagraphList.item(j) != null) {
                            Y += 70;
                            HSLFTextBox paragraphe = new HSLFTextBox();
                            paragraphe.setText(SectionsParagraphList.item(j).getTextContent());
                            paragraphe.setAnchor(new java.awt.Rectangle(300, Y, 300, 50));
                            slide.addShape(paragraphe);

                        }
                    }

                    // Recuperation des Images
                    NodeList SectionsImagesList = eElement.getElementsByTagName("ENVIMAGE");
                    for (int k = 0; k < SectionsImagesList.getLength(); k++) {
                        if (SectionsImagesList.item(k) != null) {
                            Element eImage = (Element) SectionsImagesList.item(k);
                            int ImgWidth = Integer.parseInt(eImage.getElementsByTagName("IMAGE").item(0).getAttributes().item(3).getTextContent());
                            int ImgHeight = Integer.parseInt(eImage.getElementsByTagName("IMAGE").item(0).getAttributes().item(2).getTextContent());
                            String ImgSrc = eImage.getElementsByTagName("IMAGE").item(0).getAttributes().item(1).getTextContent();

                            //Renommage du fichier image pour ne prendre que le path total;
                            ImgSrc = ImgSrc.replaceFirst("file:///", "");

                            // Ajout des images dans notre slide
                            HSLFPictureData pd = pptx.addPicture(new File(ImgSrc), PictureData.PictureType.PNG);

                            HSLFPictureShape pictNew = new HSLFPictureShape(pd);

                            // set image position in the slide
                            Y += 50;
                            pictNew.setAnchor(new java.awt.Rectangle(100, Y, 300, 200));
                            slide.addShape(pictNew);
                        }
                    }

                    // Recuperations des EL = listes � puces
                    NodeList SectionsListeList = eElement.getElementsByTagName("LISTE");
                    for (int l = 0; l < SectionsListeList.getLength(); l++) {
                        if (SectionsListeList.item(l) != null) {

                            // Ajout d'une liste a notre slide
                            HSLFTextBox shape = new HSLFTextBox();
                            HSLFTextParagraph tp = shape.getTextParagraphs().get(0);
                            tp.setBullet(true);
                            tp.setBulletChar('\u2022'); //Caractere puce point noir
                            tp.setIndent(0.);
                            tp.setLeftMargin(50.);
                            shape.setText("");

                            Element eListe = (Element) SectionsListeList.item(l);
                            NodeList SectionsElList = eListe.getElementsByTagName("EL");
                            for (int m = 0; m < SectionsElList.getLength(); m++) {
                                if (SectionsElList.item(m) != null) {
                                    shape.setText(shape.getText() + SectionsElList.item(m).getTextContent() + "\r");
                                }
                            }

                            Y += 50;
                            shape.setAnchor(new java.awt.Rectangle(50, Y, 500, 300));
                            slide.addShape(shape);
                        }
                    }

                }
            }

            try {
                FileOutputStream out = new FileOutputStream("FromEAstToPowerpoint-" + getDate() + ".ppt");
                pptx.write(out);
                out.close();
                // Boite de Dialogue
                JOptionPane.showMessageDialog(parent, "Votre fichier Powerpoint a �t� g�n�r� avec succ�s", null, JOptionPane.INFORMATION_MESSAGE);
                
            } catch (FileNotFoundException e) {
            } catch (IOException e) {
            }
        }
    }
}
