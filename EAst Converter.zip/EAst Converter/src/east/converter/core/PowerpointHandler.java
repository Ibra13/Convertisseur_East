/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package east.converter.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import javax.xml.bind.JAXBException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.xslf.usermodel.XMLSlideShow;

/**
 *
 * @author Serigne
 */
public class PowerpointHandler {

    /**
     * Permet de PARSET un fichier PPTX vers un fichier XML valide
     * @param pptxFile
     * @throws IOException
     * @throws OpenXML4JException
     * @throws JAXBException 
     */
    public void PPTX(File pptxFile) throws IOException, OpenXML4JException, JAXBException {
        PrintStream out = System.out;
        if (pptxFile.length() == 0) {
            out.println("Un fichier Powerpoint est requis pour continuer");
            return;
        }

        FileInputStream is = new FileInputStream(pptxFile);
        try (XMLSlideShow ppt = new XMLSlideShow(is)) {
            is.close();

            String nomDuFichier = pptxFile.getName();
            XmlOperations ops = new XmlOperations();
            ops.generateEastXml(nomDuFichier, ppt);
        }
    }
}
