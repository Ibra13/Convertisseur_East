/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package east.converter.core;

import east.converter.gui.ConvertToEAst;
import east.converter.gui.ConvertToPowerpoint;
import east.converter.gui.impressConvert;
import javax.swing.JFrame;

/**
 *
 * @author Serigne
 */
public class AppViewDispatcher {
    
    // cette action gere le clique sur item convertir pptx ver xml east valid
     public static void gotoConvertToEastXml(JFrame fenetre){
        fenetre.dispose();
        ConvertToEAst toEastPage = new ConvertToEAst();
        toEastPage.setVisible(true);
    }
     
    // cette action gere le clique sur item convertir un xml east vers powerpoint
    public static void gotoConvertToPowerpoint(JFrame fenetre){
        fenetre.dispose();
        ConvertToPowerpoint toPowerpointPage = new ConvertToPowerpoint();
        toPowerpointPage.setVisible(true);
    }
    
    // cette action gere le clique sur item convertir un fichier odp impress vers un xml east
    public static void gotoImpressConvert(JFrame fenetre){
        fenetre.dispose();
        impressConvert impressView = new impressConvert();
        impressView.setVisible(true);
    }
}
