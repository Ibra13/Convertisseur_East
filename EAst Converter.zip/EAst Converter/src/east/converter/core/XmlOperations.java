/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package east.converter.core;

import java.io.File;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;

import generated.*;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.poi.sl.usermodel.PictureData.PictureType;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFPictureData;
import org.apache.poi.xslf.usermodel.XSLFPictureShape;
import org.apache.poi.xslf.usermodel.XSLFShape;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFTextShape;
import org.odftoolkit.odfdom.pkg.OdfFileDom;
import org.odftoolkit.simple.PresentationDocument;
import org.odftoolkit.simple.draw.Image;
import org.odftoolkit.simple.draw.Textbox;
import org.odftoolkit.simple.meta.Meta;
import org.odftoolkit.simple.presentation.Slide;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Serigne
 */
public class XmlOperations {

    // ODP file 
    PresentationDocument presentationmodel;

    /**
     * Generer le fichier XML EAST VALID � partir de notre fichier POWERPOINT
     *
     * @param fileName
     * @param ppt
     * @throws PropertyException
     * @throws JAXBException
     */
    public void generateEastXml(String fileName, XMLSlideShow ppt) throws PropertyException, JAXBException, FileNotFoundException, IOException {

        // Instanciation d'un nouveau document EAST
        // FEUILLE EAST correspond � UNE DOCUMENT PPTX
        EAST Feuille = new EAST();
        Feuille.setPIEDPAGEGAUCHE("Utilisation de JAXB");
        Feuille.setPIEDPAGEDROIT("Samedi le 10 Fevrier 2018");

        // Ajout d'un noeud page_titre dans la feuille east
        PAGETITRE page_titre = new PAGETITRE();
        page_titre.setTITRE("Ma premier tranformation PPTX vers EAST");
        page_titre.setSOUSTITRE("In shaa Allah");
        page_titre.getAUTEUR().add("Serigne BODIAN");
        page_titre.getEMAIL().add("massebodian@mail.com");
        Feuille.setPAGETITRE(page_titre);

        // Defition de la partie
        PARTIE partie = new PARTIE();
        partie.setTITRE(fileName);

        // Ceci zone represente un SLIDE EN POWERPOINT
        // Parcours des slides present dans notre document pptx
        for (XSLFSlide slide : ppt.getSlides()) {

            // SECTIONS(EAST) = SLIDE (POWERPOINT)
            SECTION currentSection = new SECTION();

            // Parcours des zones de textes dans les slides
            int ShapeIterator = 0;
            for (XSLFShape shape : slide) {

                // UNE SHAPE EN POWERPOINT CORRESPON � UNE ZONE DANS LE SLIDE
                // ELLE PEUT CONTENIR DU TEXTE OU UNE IMAGE/VIDEO/GRAPHIQUE
                PARAGRAPHE paragraphe = new PARAGRAPHE();

                // Le shape est un TEXTE
                if (shape instanceof XSLFTextShape) {
                    XSLFTextShape txShape = (XSLFTextShape) shape;

                    // On test si le texte correspond au titre du slide
                    // Si oui on le met comme le titre de la section
                    if (txShape.getTextType() != null && txShape.getTextType().toString().equals("TITLE")) {
                        currentSection.setTITRE(txShape.getText());
                    }

                    // Recuperation du texte puis on le met dans une paragraphe EAST
                    // On ne recupere pas le texte de type PIED DE PAGE ou NUMERO DE PAGE
                    if (txShape.getTextType() != null
                            && !txShape.getTextType().toString().equals("FOOTER")
                            && !txShape.getTextType().toString().equals("SLIDE_NUMBER")) {

                        paragraphe.getContent().add(txShape.getText());
                    }
                } else if (shape instanceof XSLFPictureShape) { // SHAPE est une image
                    XSLFPictureShape pShape = (XSLFPictureShape) shape;
                    XSLFPictureData pData = pShape.getPictureData();

                    //  Recuperation & Creation des images
                    byte[] metadonnees = pData.getData();
                    PictureType type = pData.getType();
                    String imageName = "image_";
                    if (type.compareTo(PictureType.JPEG) == 0) {
                        imageName = imageName + ShapeIterator + ".jpg";
                        FileOutputStream out3 = new FileOutputStream(imageName);
                        out3.write(metadonnees);
                        out3.close();
                    } else if (type.compareTo(PictureType.PNG) == 0) {
                        imageName = imageName + ShapeIterator + ".png";
                        FileOutputStream out4 = new FileOutputStream(imageName);
                        out4.write(metadonnees);
                        out4.close();
                    }

                    // On declare un environnement IMAGE EAST
                    // C'est juste une ZONE QUI PREND une IMAGE dans la SECTION EAST
                    ENVIMAGE img_wrapper = new ENVIMAGE();
                    IMAGEOBJECT img = new IMAGEOBJECT();

                    img.setAlt("Test image");
                    img.setFichier("file:///" + new File(imageName).getAbsolutePath());
                    img.setHauteur(50);
                    img.setLargeur(50);
                    img_wrapper.setIMAGEOBJECT(img);
                    img_wrapper.setImage(img.getFichier());
                    currentSection.getPARAGRAPHEOrLISTEOrLISTEDEF().add(img_wrapper);
                } else {
                }

                //Ajout des paragraphes dans la section
                //currentSection.setTITRE("Message");
                //currentSection.setBackcolor("white");
                currentSection.getPARAGRAPHEOrLISTEOrLISTEDEF().add(paragraphe);
                ShapeIterator++;
            }

            // Ajout de la section = SLIDE qu'on vient de parcourir dans la PARTIE
            partie.getSECTION().add(currentSection);
        }

        // AU FINAL ON AJOUTE LA PARTIE DANS LA FEUILLE EAST
        Feuille.getPARTIE().add(partie);

        // Processing PPTX_EAST_XML_FILE
        File fichierXml = new File("PowerpointEAST_genere-le-" + getDate() + ".xml");
        JAXBContext context = JAXBContext.newInstance("generated");
        Marshaller jaxbMarshaller = context.createMarshaller();
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        // La on ecrit le xml dans le fichier XML
        // Ce fichier se trouve dans le r�p�etoire NETBEANS du projet
        jaxbMarshaller.marshal(Feuille, fichierXml);

        // Afficher le code xml g�n�r� dans la console pour voir le resultat
        //jaxbMarshaller.marshal(Feuille, System.out);
    }

    // Retourne la date courante de generation du fichier EAST
    public static String getDate() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDateTime now = LocalDateTime.now();
        return dtf.format(now);
    }

    /**
     * Permet de g�n�rer un fichier
     *
     * @param fileName
     * @param impressFile
     */
    public void generateImpressXml(String fileName, File impressFile) throws Exception {
        PresentationDocument presentation = (PresentationDocument) PresentationDocument.loadDocument(impressFile);
        Textbox footer = null;
        OdfFileDom metadom = presentation.getMetaDom();
        Meta metadata = new Meta(metadom);

        // Instanciation d'un nouveau document EAST
        // FEUILLE EAST correspond � UNE DOCUMENT PPTX
        EAST Feuille = new EAST();
        Feuille.setPIEDPAGEDROIT(metadata.getCreationDate().getTime().toString());

        // Ajout d'un noeud page_titre dans la feuille east
        PAGETITRE page_titre = new PAGETITRE();
        page_titre.setTITRE(metadata.getTitle());
        page_titre.getAUTEUR().add(metadata.getCreator());
        Feuille.setPAGETITRE(page_titre);

        // Defition de la partie
        PARTIE partie = new PARTIE();
        partie.setTITRE(fileName);

        for (Iterator<Slide> slideList = presentation.getSlides(); slideList.hasNext();) {
            Slide slideObject = slideList.next();
            // SECTIONS(EAST) = SLIDE (POWERPOINT)
            SECTION currentSection = new SECTION();

            // On recupere le FOOTER et on defini un OBJET FOOTER EAST
            if (footer == null) {
                try {
                    footer = slideObject.getTextboxByUsage(PresentationDocument.PresentationClass.FOOTER).get(0);
                    if (footer != null) {
                        Feuille.setPIEDPAGEGAUCHE(footer.getTextContent());
                    }
                } catch (IndexOutOfBoundsException e) {
                }
            }

            //Textbox titleBox = slideObject.getTextboxByUsage(PresentationDocument.PresentationClass.TITLE).get(0);
            //System.out.println("\n\n**Diapositive ** " + titleBox.getTextContent());
            for (Iterator<Textbox> ShapesList = slideObject.getTextboxIterator(); ShapesList.hasNext();) {

                PARAGRAPHE paragraphe = new PARAGRAPHE();

                if (slideObject.getTextboxByUsage(PresentationDocument.PresentationClass.GRAPHIC) instanceof Image) {
                    // PROCESSING des ImageElement dans le SLIDE impress
                } else {
                    // Recuperation des Textes dans le slide
                    Textbox shape = ShapesList.next();
                    paragraphe.getContent().add(shape.getTextContent());
                }

                currentSection.getPARAGRAPHEOrLISTEOrLISTEDEF().add(paragraphe);
            }

            partie.getSECTION().add(currentSection);
        }

        // AU FINAL ON AJOUTE LA PARTIE DANS LA FEUILLE EAST
        Feuille.getPARTIE().add(partie);

        // Processing PPTX_EAST_XML_FILE
        File fichierXml = new File("ImpressEAST_genere-le-" + getDate() + ".xml");
        JAXBContext context = JAXBContext.newInstance("generated");
        Marshaller jaxbMarshaller = context.createMarshaller();
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        // La on ecrit le xml dans le fichier XML
        // Ce fichier se trouve dans le r�p�etoire NETBEANS du projet
        jaxbMarshaller.marshal(Feuille, fichierXml);
    }

    /**
     * Cette fonction permet de convertir un fichier EAST xml ver Powerpoint
     *
     * @param xmlEast
     */
    public void eastXmlToPowerpoint(File xmlEast) {
        try {

            //File fXmlFile = new File("/Users/mkyong/staff.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlEast);

            //optional, but recommended
            doc.getDocumentElement().normalize();

            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

            NodeList nList = doc.getElementsByTagName("staff");

            System.out.println("----------------------------");

            for (int temp = 0; temp < nList.getLength(); temp++) {

                Node nNode = nList.item(temp);

                System.out.println("\nCurrent Element :" + nNode.getNodeName());

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                    Element eElement = (Element) nNode;

                    System.out.println("Staff id : " + eElement.getAttribute("id"));
                    System.out.println("First Name : " + eElement.getElementsByTagName("firstname").item(0).getTextContent());
                    System.out.println("Last Name : " + eElement.getElementsByTagName("lastname").item(0).getTextContent());
                    System.out.println("Nick Name : " + eElement.getElementsByTagName("nickname").item(0).getTextContent());
                    System.out.println("Salary : " + eElement.getElementsByTagName("salary").item(0).getTextContent());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
