/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package east.converter.core;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;

/**
 * Gere tous les process concerant une PRESENTATION IMPRESS de LibreOFFICE
 */
public class ImpressHandler {

    /**
     * Permet de PARSER un fichier Impress LibreOffice vers un fichier XML EAST
     * valide
     *
     * @param impressFile
     * @throws FileNotFoundException
     */
    public void IMPRESS(File impressFile) throws FileNotFoundException, Exception {
        PrintStream out = System.out;
        if (impressFile.length() == 0) {
            out.println("Un fichier IMPRESS ODP est requis pour continuer");
            return;
        }

        String nomDuFichier = impressFile.getName();
        XmlOperations ops = new XmlOperations();
        ops.generateImpressXml(nomDuFichier, impressFile);
    }
    
}
